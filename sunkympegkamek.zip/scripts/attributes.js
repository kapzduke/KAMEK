// Creates attributes for blocks
Attribute.add("stone");
Attribute.add("iron");