My first mod

Version: 0.1 beta

This mod adds a new planet with tech tree and first sector

This is a beta, it can contain bugs, if you found a bug, tell me.

At the moment mod contains:

A new planet,
     - 1 Sector,
     - 7 Blocks,
     - 3 Items,
     - 1 Turret,
     - 2 Units

Languages:
     - English
	 - Russian/Русский